import { Component, ElementRef, HostListener, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { CartService } from '../../Common-Service/cart.service';
import { ProfileService } from '../../Common-Service/profile.service';
import { WishlistService } from '../../Common-Service/wishlist.service';

@Component({
  selector: 'app-header',
  imports: [RouterLink, RouterLinkActive, FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  cart = inject(CartService);
  wishlist = inject(WishlistService);
  user = inject(ProfileService);

  private router = inject(Router);
  private host = inject(ElementRef<HTMLElement>);

  searchOpen = signal(false);
  settingsOpen = signal(false);
  profileOpen = signal(false);
  menuOpen = signal(false);
  scrolled = signal(false);

  query = '';

  @ViewChild('searchInput') searchInput?: ElementRef<HTMLInputElement>;

  toggleSearch(): void {
    const next = !this.searchOpen();
    this.closeAll();
    this.searchOpen.set(next);
    if (next) {
      setTimeout(() => this.searchInput?.nativeElement.focus(), 50);
    }
  }

  toggleSettings(): void {
    const next = !this.settingsOpen();
    this.closeAll();
    this.settingsOpen.set(next);
  }

  toggleProfile(): void {
    const next = !this.profileOpen();
    this.closeAll();
    this.profileOpen.set(next);
  }

  toggleMenu(): void {
    const next = !this.menuOpen();
    this.closeAll();
    this.menuOpen.set(next);
  }

  submitSearch(): void {
    const q = this.query.trim();
    if (!q) return;
    this.router.navigate(['/shop'], { queryParams: { q } });
    this.closeAll();
  }

  closeAll(): void {
    this.searchOpen.set(false);
    this.settingsOpen.set(false);
    this.profileOpen.set(false);
    this.menuOpen.set(false);
  }

  // Slightly compact header with a shadow once the page is scrolled.
  @HostListener('window:scroll')
  onScroll(): void {
    this.scrolled.set(window.scrollY > 8);
  }

  // Close any open panel when the user clicks outside the header.
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.host.nativeElement.contains(event.target as Node)) {
      this.closeAll();
    }
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.closeAll();
  }
}