import { Routes } from '@angular/router';
import { HomeComponent } from './Pages/home/home.component';
import { ProductListComponent } from './Pages/product-list/product-list.component';
import { ProductDetailsComponent } from './Pages/product-details/product-details.component';
import { BrandsComponent } from './Pages/brands/brands.component';
import { OrderDetailsComponent } from './Pages/order-details/order-details.component';

export const routes: Routes = [
    {
        path: '',
        component: HomeComponent,
        title: 'ShoeKart | Home'
    },
    {
        path: 'brands',
        component: BrandsComponent,
        title: 'ShoeKart | Brands'

    },
    
    {
        path: 'products',
        component: ProductListComponent,
        title: 'ShoeKart | Products'
    },
    {
        path: 'products/:id',
        component: ProductDetailsComponent,
        title: 'ShoeKart | Product Details'
    },
    {
        path: 'orders',
        component: OrderDetailsComponent,
        title: 'ShoeKart | My Orders'
    },
    {
        path: '**',
        redirectTo: ''
    }

];
