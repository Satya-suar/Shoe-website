import { CurrencyPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom, forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { CartService } from '../../Common-Service/cart.service';
import { InvoiceItem, InvoiceService } from '../../Common-Service/invoice.service';
import { MyServiceService } from '../../Common-Service/my-service.service';
import { ProfileService } from '../../Common-Service/profile.service';
import { SettingsService } from '../../Common-Service/settings.service';

@Component({
  selector: 'app-checkout',
  imports: [RouterLink, ReactiveFormsModule, CurrencyPipe],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent implements OnInit {
  cart = inject(CartService);
  user = inject(ProfileService);
  private settings = inject(SettingsService);
  private invoices = inject(InvoiceService);
  private api = inject(MyServiceService);
  private router = inject(Router);
  private fb = inject(FormBuilder);

  busy = signal(false);

  form = this.fb.group({
    customerName: ['', [Validators.required, Validators.minLength(3)]],
    mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
    email: ['', [Validators.required, Validators.email]],
    address: ['', [Validators.required, Validators.minLength(10)]]
  });

  get f() {
    return this.form.controls;
  }

  ngOnInit(): void {
    if (!this.settings.settings().prefillCheckout) return;
    const p = this.user.profile();
    const first = this.user.addresses()[0];
    this.form.patchValue({
      customerName: p.name && p.name !== 'Guest User' ? p.name : '',
      mobileNumber: p.phone || '',
      email: p.email || '',
      address: first ? `${first.line}, ${first.city} ${first.pincode}` : ''
    });
  }

  useSaved(id: string): void {
    const a = this.user.addresses().find(x => String(x.id) === id);
    if (a) this.form.patchValue({ address: `${a.line}, ${a.city} ${a.pincode}` });
  }

  /**
   * The store API places one order per pair, so each pair in the cart becomes its own order.
   * Product details are checked first (brand id, current price and stock).
   */
  async placeOrder(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const customer = {
      customerName: this.form.value.customerName!,
      mobileNumber: this.form.value.mobileNumber!,
      email: this.form.value.email!,
      address: this.form.value.address!
    };

    this.busy.set(true);
    const lines = this.cart.items();
    const ids = [...new Set(lines.map(l => l.id))];

    const details = await firstValueFrom(
      forkJoin(ids.map(id => this.api.getProductDetails(id).pipe(map((r: any) => r?.data ?? null), catchError(() => of(null)))))
    );
    const byId = new Map<number, any>(ids.map((id, i) => [id, details[i]]));

    const placed: InvoiceItem[] = [];
    const problems: string[] = [];
    let orderRef: string | number | undefined;

    for (const line of lines) {
      const d = byId.get(line.id);
      if (!d) { problems.push(`${line.name}: could not be checked`); continue; }
      if (!d.isStock) { problems.push(`${line.name}: out of stock`); continue; }

      let ok = 0;
      for (let n = 0; n < line.qty; n++) {
        try {
          const res: any = await firstValueFrom(this.api.placeOrder({
            productId: d.productId ?? line.id,
            brandId: d.brandId,
            price: d.price,
            ...customer
          }));
          orderRef ??= typeof res?.data === 'number' ? res.data : (res?.data?.orderId ?? res?.data?.id ?? res?.orderId);
          ok++;
        } catch {
          break;
        }
      }

      if (ok > 0) {
        placed.push({
          name: line.name,
          brand: d.brandName,
          size: line.size,
          color: d.color,
          qty: ok,
          price: Number(d.price),
          image: line.image
        });
      }

      if (ok === line.qty) {
        this.cart.remove(line.id, line.size);
      } else {
        if (ok > 0) this.cart.setQty(line.id, line.qty - ok, line.size);
        problems.push(`${line.name}: ${ok} of ${line.qty} placed`);
      }
    }

    this.busy.set(false);

    if (placed.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'Order failed',
        text: problems.length ? problems.join('. ') : 'Something went wrong. Please try again.',
        confirmButtonColor: '#e10b1f'
      });
      return;
    }

    const invoice = this.invoices.create(
      { name: customer.customerName, mobile: customer.mobileNumber, email: customer.email, address: customer.address },
      placed,
      orderRef
    );

    await Swal.fire({
      icon: problems.length ? 'warning' : 'success',
      title: problems.length ? 'Order partly placed' : 'Order placed!',
      text: problems.length ? problems.join('. ') + '. These stay in your cart.' : 'Your order has been placed successfully.',
      footer: `Invoice ${invoice.no} is ready`,
      confirmButtonText: 'View invoice',
      confirmButtonColor: '#e10b1f'
    });
    this.router.navigate(['/invoice', invoice.no]);
  }
}
